create table fpt_SSO_auth_conf(ID number,Auth_method varchar2(50),CREATION_DATE date,CREATED_BY number,LAST_UPDATE_DATE date,LAST_UPDATED_BY number);

create table fpt_SSO_ADFS_conf(ID number,
Auth_Type varchar2(50),
Url_Request varchar2(1000),
Url_Token varchar2(1000),
Url_Logout varchar2(1000),
CREATION_DATE date,CREATED_BY number,LAST_UPDATE_DATE date,LAST_UPDATED_BY number);

create table fpt_SSO_AD_EXCLUDE(ID number,
USER_NAME varchar2(100),
ENABLE_FLAG varchar2(1),
FROM_DATE date,
TO_DATE date,
CREATION_DATE date,CREATED_BY number,LAST_UPDATE_DATE date,LAST_UPDATED_BY number);

create table fpt_SSO_AD_CONF(ID number,
AD_NAME varchar2(100),
AD_HOST varchar2(100),
AD_POST varchar2(10),
AD_USER varchar2(100),
AD_PASS varchar2(100),
AD_BASE varchar2(100),
AD_FILTER varchar2(240),
ENABLE_FLAG varchar2(10),
CREATION_DATE date,CREATED_BY number,LAST_UPDATE_DATE date,LAST_UPDATED_BY number);

-- Create sequence 
create sequence fpt_SSO_AD_CONF_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;

-- Create sequence 
create sequence fpt_SSO_auth_conf_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;

-- Create sequence 
create sequence fpt_SSO_ADFS_conf_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;

-- Create sequence 
create sequence fpt_SSO_AD_EXCLUDE_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;


create table fpt_SSO_LOG(ID number,
Auth_Type varchar2(50),
Status varchar2(10),
User_Name varchar2(100),
Error_message varchar2(4000),
CREATION_DATE date
);

-- Create sequence 
create sequence fpt_SSO_LOG_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
cache 20;

create table fpt_SSO_auth_conf_his(
Action varchar2(50),
Table_conf_name varchar2(50),
ID number,
Auth_method varchar2(50),
---------------------------------
Auth_Type varchar2(50),
Url_Request varchar2(1000),
Url_Token varchar2(1000),
Url_Logout varchar2(1000),
-------------------
AD_NAME varchar2(100),
AD_HOST varchar2(100),
AD_POST varchar2(10),
AD_USER varchar2(100),
AD_PASS varchar2(100),
AD_BASE varchar2(100),
AD_FILTER varchar2(240),
AD_ENABLE_FLAG varchar2(10),
----------------------
USER_NAME varchar2(100),
ENABLE_FLAG varchar2(1),
FROM_DATE date,
TO_DATE date,
Action_BY number,
Action_Time date);

--init data config
insert into fpt_SSO_auth_conf (ID, AUTH_METHOD, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, CREATION_DATE)
values (1, 'LDAP', 0, sysdate, 0, null);

insert into fpt_SSO_ADFS_conf (ID, AUTH_TYPE, URL_REQUEST, URL_TOKEN, URL_LOGOUT, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY)
values (1, 'SAML', 'https://adfs2.fes.com.vn/adfs/ls/IdpInitiatedSignOn.aspx?loginToRp=ebs', 'https://adfs2.fes.com.vn:44308/api/ADFS/ADFS_SAML_Decrypt', 'https://adfs2.fes.com.vn/adfs/ls/?wa=wsignout1.0', sysdate, 0, sysdate, 0);



